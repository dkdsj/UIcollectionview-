# CollectionViewDemos

UIColectionView学习demo集合，配有博文讲解！

#专题文章

* [Demo1:CollectionView网格布局](http://www.henishuo.com/collectionview-grid-layout/)
* [Demo1:CollectionView列表性能优化](http://www.henishuo.com/collectionview-performace/)
* [Demo2:CollectionView旋转水平卡片布局](http://www.henishuo.com/collectiontion-card-layout/)
* [Demo3:CollectionView缩放水平卡片布局](http://www.henishuo.com/collectionview-flowlayout-card-scale/)
* [Demo4:CollectionView垂直缩放卡片布局](http://www.henishuo.com/collectionview-vertical-scale-card/)


