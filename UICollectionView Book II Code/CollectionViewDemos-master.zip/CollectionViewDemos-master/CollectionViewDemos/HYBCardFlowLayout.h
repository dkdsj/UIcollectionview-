//
//  HYBCardFlowLayout.h
//  CollectionViewDemos
//
//  Created by huangyibiao on 16/3/26.
//  Copyright © 2016年 huangyibiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HYBCardFlowLayout : UICollectionViewFlowLayout

@end
